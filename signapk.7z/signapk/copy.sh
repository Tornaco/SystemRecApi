cp app/build/outputs/apk/app-release.apk signapk/
