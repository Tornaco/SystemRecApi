cp -rf ./patch/AndroidManifest.xml ./app/src/main/
